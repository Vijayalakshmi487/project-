#include<iostream>
using namespace std;
int main()
{
    int row,column,i,j,a[10][10];
    cin>>row;
    cin>>column;
    for(i=0;i<row;i++)
    {
        for(j=0;j<column;j++)
        {
            cin>>a[i][j];
        }
    }
    for(i=0;i<row;i++)
    {
        if(i%2==0)
        {
            for(j=column-1;j>=0;j--)
            {
                cout<<a[i][j]<<" ";
            }
        }
        else
        {
            for(j=0;j<column;j++)
            {
                cout<<a[i][j]<<" ";
            }
            
        }
    }
}