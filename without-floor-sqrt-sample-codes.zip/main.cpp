#include<stdio.h>
int main()
{
    int n,i;
    scanf("%d",&n);
    for(i=1;i<n/2;i++)
    {
        if(n==i*i)
        break;
    }
    printf("%d",i);
    return 0;
}
