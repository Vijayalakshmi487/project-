#include <stdio.h>
int main() {
	int i, j, k, x;
	scanf("%d",&j);
	for (i=1;i<=j;i++) {
		for (k=1;k<=j;k++) {
			printf(" ");
		}
		for (x=1;x<=i;x++) {
			printf("%d",i);
			printf(" ");
		}
		printf("\n");

	}
	return 0;
}