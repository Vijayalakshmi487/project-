#include<iostream>
using namespace std;
int main( )
{
 int i,j,k,p,q,flag,e,x,d;
 cout<<"\n RSA ALGORITHM \n\n\n ";
 cout<<" \n Enter Value of p :: ";
 cin>>p;
 cout<<" \n Enter Value of q :: ";
 cin>>q;
 int n=p*q;
 int fn=(p-1)*(q-1);
 cout<<"\n Value of (p,q) :: "<<p<<" "<<q;
 cout<<"\n Value of n,fn :: "<<n<<" "<<fn;
 cout<<"\n\n Select Public Key e (1 < e<"<<fn<<")";
 cin>>e;
 int sk;
 for(i=1;i>0;i++)
 {
 x=i*e;
 d=x%fn;
 if(d==1)
 {
 cout<<"\n\n Private Key ::"<< i; 
 sk = i;
 break;
 }
 }
 int pt;
 cout<<"\n\n Enter Plain Text ::";
 cin>>pt;
 int m=1;
 for(i=0;i<e;i++)
 m=(m*pt)%n;
 m=m%n;
 cout<<"\n\n Cipher Text :: "<<m;
 k=1;
 for(i=0;i<sk;i++)
 k=(k*m)%n;
 k=k%n;
 cout<<"\n\n Decrypted Text :: "<<k;
 return 0;
} 