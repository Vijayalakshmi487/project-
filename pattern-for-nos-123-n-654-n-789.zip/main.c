#include<stdio.h>
int main()
{
    int i,j,n,ans,diff;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        if(i%2==0)
        {
            ans=n*i;
            diff=-1;
        }
        else
        {
            ans=(i-1)*n+1;
            diff=1;
        }
        for(j=1;j<=n;j++)
        {
            printf("%d",ans);
            ans=ans+diff;
        }
        printf("\n");
    }
    return 0;
}