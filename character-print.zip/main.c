#include<stdio.h>
int main()
{
    char ch1,ch2,ch3;
    for(ch1='A';ch1<='C';++ch1)
    {
        for(ch2='A';ch2<='C';++ch2)
        {
            for(ch3='A';ch3<='C';++ch3)
            {
                printf(" %c%c%c",ch1,ch2,ch3);
            }
        }
    }
    return 0;
}