#include<stdio.h>
int main()
{
    int n=7,i,j;
    int k=1;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            printf("%d  ",k);
            k++;
        }
        printf("\n");
        k=k+i;
        i++;
        for(j=1;j<=i && i<=n;j++)
        {
            printf("%d  ",k);
            k--;
        }
        printf("\n");
        k=k+i+1;
    }
    return 0;
}