#include<stdio.h>
int main()
{
    int n1,n2,n,i,c=0,r;
    scanf("%d%d",&n1,&n2);
    for(i=n1;i<=n2;i++)
    {
        n=i;
        while(n!=0)
        {
            r=n1%10;
            if(r==n)
            c++;
            n=n/10;
        }
    }
    printf("%d",c);
    return 0;
}