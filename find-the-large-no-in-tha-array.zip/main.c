#include<stdio.h>
int main()
{
    int a[10],i,n,max=0,size;
    printf("enter the size of array");
    scanf("%d",&size);
    for(i=0;i<size;i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    for(i=1;i<size;i++)
    {
        if(a[i]>max)
        {
        max=a[i];
        }
    }
    printf("%d",max);
    return 0;
}