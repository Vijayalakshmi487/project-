#include<stdio.h>
#define MAX 1000
int main()
{
    char octnum[MAX];
    int i=0;
    scanf("%s",&octnum);
    printf("octalnum--->binary\n");
    while(octnum[i])
    {
        switch(octnum[i])
        {
            case '0':
            printf("001");
            break;
            case '1':
            printf("010");
            break;
            case '2':
            printf("011");
            break;
            case '3':
            printf("100");
            break;
            case '4':
            printf("101");
            break;
            case '5':
            printf("110");
            break;
            case '6':
            printf("111");
            break;
            default:
            printf("%c is invalid digit",octnum[i]);
        }
        i++;
    }
    return 0;
}