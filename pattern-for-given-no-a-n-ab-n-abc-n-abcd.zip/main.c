#include<stdio.h>
int main()
{
    char n;
    int num,c=1,k;
    scanf("%d",&num);
    scanf("%c",&n);
    for(k='A';k<='Z';k++)
    {
        if(c==num)
        {
            n=k ;
            break;
        }
        c++;
    }
    for(char i='A';i<=n;i++)
    {
        for(char j='A';j<=i;j++)
        {
            printf("%c ",j);
        }
        printf("\n");
    }
    return 0;
}
