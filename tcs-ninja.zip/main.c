#include<stdio.h>
int main()
{
    int a[100],j,n,sum_odd=0,sum_even=0,diff,i;
    scanf("%d",&n);
    j=1;
    while(n!=0)
    {
    a[j]=n%10;
    n=n/10;
    j++;
    }
    for(i=1;i<=j;i++)
    {
        if(i%2==0)
        {
            sum_odd=sum_odd+i;
        }
        else
        {
         sum_even=sum_even+i;
        }
    }
    if(sum_odd>sum_even)
    {
        diff=sum_odd-sum_even;
    }
    else
    diff=sum_even-sum_odd;
    printf("%d",diff);
    return 0;
}