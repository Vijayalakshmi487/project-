#include<stdio.h>
int main()
{
    int i,a=0,b=0,n;
    scanf("%d",&n);
    for(i=3;i<=n;i++)
    {
        if(i%2!=0)
        {
        a=a+7;
        }
        else
        {
            b=b+6;
        }
    }
    if(n%2!=0)
    {
        printf("%d",a);
    }
    else
    {
        printf("%d",b);
    }
    return 0;
    
}